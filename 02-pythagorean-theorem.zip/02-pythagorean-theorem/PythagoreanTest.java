public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean pythagorean = new Pythagorean();
        System.out.println(pythagorean.calculateHypotenuse(1,3));
    }
}