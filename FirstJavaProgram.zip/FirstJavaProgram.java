public class FirstJavaProgram {
    public static void main(String[] args) {
        System.out.println(
        "My name is Jeremy Akatsa. I am 32 years old. My hometown is San Jose, CA"
        );
    }
}